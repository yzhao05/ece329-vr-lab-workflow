---
name: editor-selection-get
description: Get information about the current Selection in the Unity Editor — active object, active transform, selected GameObjects, transforms, instance IDs, and asset GUIDs (each enrichment is opt-in). Pair with 'editor-selection-set' to change the selection.
---

# Editor / Selection / Get

Get information about the current Selection in the Unity Editor. Use 'editor-selection-set' tool to set the selection.

## Toggles (default off where indicated to keep responses small)

- `includeGameObjects` (default `false`) — populate `GameObjects[]`.
- `includeTransforms` (default `false`) — populate `Transforms[]` as `ComponentRef`s.
- `includeInstanceIDs` (default `false`) — populate `InstanceIDs[]`.
- `includeAssetGUIDs` (default `false`) — populate `AssetGUIDs[]` from project-window selection.
- `includeActiveObject` (default `true`) — populate `ActiveObject` as a generic `ObjectRef`.
- `includeActiveTransform` (default `true`) — populate `ActiveTransform` as a `ComponentRef`.

`ActiveGameObject` and `ActiveInstanceID` are always populated.

## How to Call

```bash
unity-mcp-cli run-tool editor-selection-get --input '{
  "includeGameObjects": false,
  "includeTransforms": false,
  "includeInstanceIDs": false,
  "includeAssetGUIDs": false,
  "includeActiveObject": false,
  "includeActiveTransform": false
}'
```

> For complex input (multi-line strings, code), save the JSON to a file and use:
> ```bash
> unity-mcp-cli run-tool editor-selection-get --input-file args.json
> ```
>
> Or pipe via stdin (recommended):
> ```bash
> unity-mcp-cli run-tool editor-selection-get --input-file - <<'EOF'
> {"param": "value"}
> EOF
> ```


### Troubleshooting

If `unity-mcp-cli` is not found, either install it globally (`npm install -g unity-mcp-cli`) or use `npx unity-mcp-cli` instead.
Read the /unity-initial-setup skill for detailed installation instructions.

## Input

| Name | Type | Required | Description |
|------|------|----------|-------------|
| `includeGameObjects` | `boolean` | No |  |
| `includeTransforms` | `boolean` | No |  |
| `includeInstanceIDs` | `boolean` | No |  |
| `includeAssetGUIDs` | `boolean` | No |  |
| `includeActiveObject` | `boolean` | No |  |
| `includeActiveTransform` | `boolean` | No |  |

### Input JSON Schema

```json
{
  "type": "object",
  "properties": {
    "includeGameObjects": {
      "type": "boolean"
    },
    "includeTransforms": {
      "type": "boolean"
    },
    "includeInstanceIDs": {
      "type": "boolean"
    },
    "includeAssetGUIDs": {
      "type": "boolean"
    },
    "includeActiveObject": {
      "type": "boolean"
    },
    "includeActiveTransform": {
      "type": "boolean"
    }
  }
}
```

## Output

### Output JSON Schema

```json
{
  "type": "object",
  "properties": {
    "result": {
      "$ref": "#/$defs/AIGD.SelectionData"
    }
  },
  "$defs": {
    "AIGD.GameObjectRef-1": {
      "type": "array",
      "items": {
        "$ref": "#/$defs/AIGD.GameObjectRef",
        "description": "Find GameObject in opened Prefab or in the active Scene."
      }
    },
    "AIGD.GameObjectRef": {
      "type": "object",
      "properties": {
        "instanceID": {
          "type": "integer",
          "description": "instanceID of the UnityEngine.Object. If it is '0' and 'path', 'name', 'assetPath' and 'assetGuid' is not provided, empty or null, then it will be used as 'null'. Priority: 1 (Recommended)"
        },
        "path": {
          "type": "string",
          "description": "Path of a GameObject in the hierarchy Sample 'character/hand/finger/particle'. Priority: 2."
        },
        "name": {
          "type": "string",
          "description": "Name of a GameObject in hierarchy. Priority: 3."
        },
        "assetType": {
          "$ref": "#/$defs/System.Type",
          "description": "Type of the asset."
        },
        "assetPath": {
          "type": "string",
          "description": "Path to the asset within the project. Starts with 'Assets/'"
        },
        "assetGuid": {
          "type": "string",
          "description": "Unique identifier for the asset."
        }
      },
      "required": [
        "instanceID"
      ],
      "description": "Find GameObject in opened Prefab or in the active Scene."
    },
    "System.Type": {
      "type": "string"
    },
    "AIGD.ComponentRef-1": {
      "type": "array",
      "items": {
        "$ref": "#/$defs/AIGD.ComponentRef",
        "description": "Component reference. Used to find a Component at GameObject."
      }
    },
    "AIGD.ComponentRef": {
      "type": "object",
      "properties": {
        "index": {
          "type": "integer",
          "description": "Component 'index' attached to a gameObject. The first index is '0' and that is usually Transform or RectTransform. Priority: 2. Default value is -1."
        },
        "typeName": {
          "type": "string",
          "description": "Component type full name. Sample 'UnityEngine.Transform'. If the gameObject has two components of the same type, the output component is unpredictable. Priority: 3. Default value is null."
        },
        "instanceID": {
          "type": "integer",
          "description": "instanceID of the UnityEngine.Object. If this is '0', then it will be used as 'null'."
        }
      },
      "required": [
        "index",
        "instanceID"
      ],
      "description": "Component reference. Used to find a Component at GameObject."
    },
    "System.Int32-1": {
      "type": "array",
      "items": {
        "type": "integer"
      }
    },
    "System.String-1": {
      "type": "array",
      "items": {
        "type": "string"
      }
    },
    "AIGD.ObjectRef": {
      "type": "object",
      "properties": {
        "instanceID": {
          "type": "integer",
          "description": "instanceID of the UnityEngine.Object. If this is '0', then it will be used as 'null'."
        }
      },
      "required": [
        "instanceID"
      ],
      "description": "Reference to UnityEngine.Object instance. It could be GameObject, Component, Asset, etc. Anything extended from UnityEngine.Object."
    },
    "AIGD.SelectionData": {
      "type": "object",
      "properties": {
        "GameObjects": {
          "$ref": "#/$defs/AIGD.GameObjectRef-1",
          "description": "Returns the actual game object selection. Includes Prefabs, non-modifiable objects."
        },
        "Transforms": {
          "$ref": "#/$defs/AIGD.ComponentRef-1",
          "description": "Returns the top level selection, excluding Prefabs."
        },
        "InstanceIDs": {
          "$ref": "#/$defs/System.Int32-1",
          "description": "The actual unfiltered selection from the Scene returned as instance ids instead of objects."
        },
        "AssetGUIDs": {
          "$ref": "#/$defs/System.String-1",
          "description": "Returns the guids of the selected assets."
        },
        "ActiveGameObject": {
          "$ref": "#/$defs/AIGD.GameObjectRef",
          "description": "Returns the active game object. (The one shown in the inspector)."
        },
        "ActiveInstanceID": {
          "type": "integer",
          "description": "Returns the instanceID of the actual object selection. Includes Prefabs, non-modifiable objects"
        },
        "ActiveObject": {
          "$ref": "#/$defs/AIGD.ObjectRef",
          "description": "Returns the actual object selection. Includes Prefabs, non-modifiable objects."
        },
        "ActiveTransform": {
          "$ref": "#/$defs/AIGD.ComponentRef",
          "description": "Returns the active transform. (The one shown in the inspector)."
        }
      },
      "required": [
        "ActiveInstanceID"
      ]
    }
  },
  "required": [
    "result"
  ]
}
```

